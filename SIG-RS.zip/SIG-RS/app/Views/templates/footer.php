</div> <!-- .content -->
  </div> <!-- .site-wrap -->

  <script src="/aseets/js/jquery-3.3.1.min.js"></script>
  <script src="/aseets/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="/aseets/js/jquery.easing.1.3.js"></script>
  <script src="/aseets/js/jquery-ui.js"></script>
  <script src="/aseets/js/popper.min.js"></script>
  <script src="/aseets/js/bootstrap.min.js"></script>
  <script src="/aseets/js/owl.carousel.min.js"></script>
  <script src="/aseets/js/jquery.stellar.min.js"></script>
  <script src="/aseets/js/jquery.countdown.min.js"></script>
  <script src="/aseets/js/jquery.magnific-popup.min.js"></script>
  <script src="/aseets/js/aos.js"></script>
  <script src="/aseets/js/lozad.min.js"></script>
  <script src="/aseets/js/jquery.fancybox.min.js"></script>
  <script src="/aseets/js/main.js"></script>
</body>
</html>
